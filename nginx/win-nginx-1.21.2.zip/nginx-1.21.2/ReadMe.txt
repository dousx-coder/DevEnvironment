nginx-service uninstall

nginx-service install